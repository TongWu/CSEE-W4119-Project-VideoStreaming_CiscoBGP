# Project 1 CSEE4119

To get the newest version of starter code:

		git pull origin master